/**
 * บันทึกคะแนนสอบ Pre-RT / Pre-NT / Pre-O-NET  →  Google Sheets
 * วางไฟล์นี้เป็น code.gs และสร้างไฟล์ HTML ชื่อ "Index" (เนื้อหาจาก Index.html)
 * ผูกกับ Google Sheet ที่เปิด Extensions → Apps Script
 */
const SHEETS = { RT: 'Pre-RT', NT: 'Pre-NT', ONET: 'Pre-O-NET' };

function doGet(e) {
  if (e && e.parameter && e.parameter.action === 'load') {
    if (!auth_(e.parameter.key)) return json_({ error: 'unauthorized' });
    return json_(loadAll());
  }
  return HtmlService.createHtmlOutputFromFile('Index')
    .setTitle('บันทึกคะแนนสอบ')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1');
}

// ใช้ชีตที่ผูกกับสคริปต์ ถ้าเป็นสคริปต์อิสระให้ตั้ง SHEET_ID ใน Script Properties
function ss_() {
  const a = SpreadsheetApp.getActiveSpreadsheet();
  if (a) return a;
  const id = PropertiesService.getScriptProperties().getProperty('SHEET_ID');
  if (!id) throw new Error('ไม่พบ Google Sheet: ผูกสคริปต์กับชีต หรือตั้งค่า SHEET_ID');
  return SpreadsheetApp.openById(id);
}

// อ่านข้อมูลนักเรียนทั้งหมด (เก็บเป็น JSON ในคอลัมน์สุดท้ายที่ซ่อนไว้)
function loadAll() {
  const D = { RT: [], NT: [], ONET: [] };
  Object.keys(SHEETS).forEach(function (ex) {
    const sh = ss_().getSheetByName(SHEETS[ex]);
    if (!sh || sh.getLastRow() < 2) return;
    const col = sh.getLastColumn();
    sh.getRange(2, col, sh.getLastRow() - 1, 1).getValues().forEach(function (r) {
      try { if (r[0]) D[ex].push(JSON.parse(r[0])); } catch (e) {}
    });
  });
  return { D: D, school: PropertiesService.getScriptProperties().getProperty('school') || '' };
}

// เขียนทั้งชีตใหม่: แถว 1 = หัวตาราง, แถวถัดไป = นักเรียนคนละแถว
function saveExam(ex, aoa) {
  if (!SHEETS[ex]) throw new Error('ไม่รู้จักชุดข้อสอบ: ' + ex);
  const lock = LockService.getScriptLock();
  lock.waitLock(30000);
  try {
    const ss = ss_();
    const sh = ss.getSheetByName(SHEETS[ex]) || ss.insertSheet(SHEETS[ex]);
    sh.clearContents();
    const w = aoa[0].length;
    sh.getRange(1, 1, aoa.length, w).setValues(aoa);
    sh.setFrozenRows(1);
    sh.setFrozenColumns(5);
    sh.getRange(1, 1, 1, w).setFontWeight('bold').setBackground('#e3f3f0');
    sh.hideColumns(w); // คอลัมน์ _data ใช้โหลดกลับเข้าแอป ห้ามลบ
  } finally {
    lock.releaseLock();
  }
}

function saveSettings(school) {
  PropertiesService.getScriptProperties().setProperty('school', String(school || ''));
}

// ===== API สำหรับแอป Android (APK) =====
// ถ้าต้องการรหัสผ่าน: Project Settings → Script Properties → เพิ่ม API_KEY
function doPost(e) {
  try {
    const b = JSON.parse(e.postData.contents);
    if (!auth_(b.key)) return json_({ error: 'unauthorized' });
    if (b.action === 'saveExam') saveExam(b.ex, b.aoa);
    else if (b.action === 'saveSettings') saveSettings(b.school);
    else return json_({ error: 'bad action' });
    return json_({ ok: true });
  } catch (err) {
    return json_({ error: String(err) });
  }
}
function auth_(k) {
  const p = PropertiesService.getScriptProperties().getProperty('API_KEY');
  return !p || p === k;
}
function json_(o) {
  return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
}
